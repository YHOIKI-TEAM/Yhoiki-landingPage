import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import About from "@/components/About";
import OrganizationStructure from "@/components/OrganizationStructure";
import LegalInfo from "@/components/LegalInfo";
import BusinessUnits from "@/components/BusinessUnits";
import Services from "@/components/Services";
import Footer from "@/components/Footer";
import Partners from "@/components/Partners";
import WhyChooseUs from "@/components/WhyChooseUs";
import FutureGoals from "@/components/FutureGoals";
import CTA from "@/components/CTA";
import Portofolio from "@/components/Portofolio";

export default function Home() {
  return (
    <main className="min-h-screen" style={{ backgroundColor: "var(--warna-bg-dasar)" }}>
      <Navbar />
      <Hero />
      <Partners />
      <About />
      <OrganizationStructure />
      <LegalInfo />
      <BusinessUnits />
      <Services />
      <WhyChooseUs />
      <FutureGoals />
      <Portofolio />
      <CTA />
      <Footer />
    </main>
  );
}
