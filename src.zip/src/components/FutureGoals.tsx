"use client";

import { useEffect, useRef } from "react";
import { Network, Globe2, BrainCircuit, Rocket } from "lucide-react";

interface DataTujuan {
  Icon: typeof Network;
  nomor: string;
  judul: string;
  deskripsi: string;
}

const daftarTujuan: DataTujuan[] = [
  {
    Icon: Network,
    nomor: "01",
    judul: "Build Scalable Digital Ecosystem",
    deskripsi: "Membangun ekosistem digital yang saling terintegrasi dan scalable.",
  },
  {
    Icon: Globe2,
    nomor: "02",
    judul: "International Expansion",
    deskripsi: "Mengembangkan perusahaan menuju pasar global.",
  },
  {
    Icon: BrainCircuit,
    nomor: "03",
    judul: "AI & Technology Innovation",
    deskripsi: "Mengembangkan produk dan layanan berbasis AI serta teknologi modern.",
  },
  {
    Icon: Rocket,
    nomor: "04",
    judul: "Product & Startup Development",
    deskripsi: "Membangun berbagai produk digital inovatif di bawah ekosistem perusahaan.",
  },
];

function gunakanAnimasiFadeUp(ref: React.RefObject<HTMLDivElement | null>) {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) entry.target.classList.add("visible");
        });
      },
      { threshold: 0.1 },
    );
    ref.current?.querySelectorAll(".fade-up").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}

function ItemTujuan({ data, index }: { data: DataTujuan; index: number }) {
  return (
    <div
      className="fade-up group flex items-start gap-5 rounded-2xl bg-[rgba(var(--warna-brand-rgb),0.05)] p-6 transition-colors hover:bg-[rgba(var(--warna-brand-rgb),0.1)]"
      style={{ transitionDelay: `${index * 100}ms` }}
    >
      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[rgba(var(--warna-brand-rgb),0.2)] transition-transform duration-300 group-hover:scale-105">
        <data.Icon size={22} className="text-[var(--warna-aksen)]" />
      </div>
      <div>
        <div className="mb-1 text-xs font-bold tracking-widest text-[var(--warna-brand)]">{data.nomor}</div>
        <h3 className="mb-2 text-lg font-bold text-[var(--warna-teks-utama)] md:text-xl">{data.judul}</h3>
        <p className="text-sm leading-relaxed text-[var(--warna-teks-sekunder)]">{data.deskripsi}</p>
      </div>
    </div>
  );
}

export default function FutureGoals() {
  const sectionRef = useRef<HTMLDivElement>(null);
  gunakanAnimasiFadeUp(sectionRef);

  return (
    <section
      id="future-goals"
      ref={sectionRef}
      className="relative overflow-hidden bg-[var(--warna-bg-dasar)] py-24"
    >
      <div className="bg-dots absolute inset-0 opacity-20" />
      <div
        className="pointer-events-none absolute top-0 left-0 h-150 w-150"
        style={{
          background:
            "radial-gradient(circle at 20% 20%, rgba(var(--warna-brand-rgb),0.08) 0%, transparent 60%)",
        }}
      />

      <div className="relative z-10 mx-auto max-w-7xl px-6">
        <div className="fade-up mx-auto mb-14 max-w-2xl text-center">
          <h2 className="mb-4 text-4xl font-bold tracking-tight text-[var(--warna-teks-utama)] lg:text-5xl">
            Future <span className="text-[var(--warna-brand)]">Goals</span>
          </h2>
          <p className="text-sm text-[var(--warna-teks-sekunder)] md:text-base">
            Arah pertumbuhan jangka panjang yang menjadi fokus pengembangan Yhoiki ke depan.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
          {daftarTujuan.map((data, index) => (
            <ItemTujuan key={data.nomor} data={data} index={index} />
          ))}
        </div>
      </div>

      <style
        dangerouslySetInnerHTML={{
          __html: `.fade-up {
 opacity: 0;
 transform: translateY(20px);
 transition: opacity 0.6s ease-out, transform 0.6s ease-out;
 }
 .fade-up.visible {
 opacity: 1;
 transform: translateY(0);
 }`,
        }}
      />
    </section>
  );
}
