"use client";

import { useEffect, useRef } from "react";

interface DataPengurus {
  nama: string;
  posisi: string;
  inisial: string;
}

const daftarPengurus: DataPengurus[] = [
  { nama: "Resta Nugroho", posisi: "CEO", inisial: "RN" },
  { nama: "Aries Wijaya K.", posisi: "COO", inisial: "AW" },
  { nama: "Anggun Amalia", posisi: "CFO", inisial: "AA" },
  { nama: "Afanin Musfida", posisi: "CTO", inisial: "AM" },
];

function gunakanAnimasiFadeUp(ref: React.RefObject<HTMLDivElement | null>) {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) entry.target.classList.add("visible");
        });
      },
      { threshold: 0.1 },
    );
    ref.current?.querySelectorAll(".fade-up").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}

function KartuPengurus({ data, index }: { data: DataPengurus; index: number }) {
  return (
    <div
      className="fade-up group relative flex flex-col items-center overflow-hidden kartu-shadow rounded-2xl bg-[var(--warna-bg-permukaan)] p-8 text-center transition-colors hover:bg-[var(--warna-bg-permukaan-2)]"
      style={{ transitionDelay: `${index * 100}ms` }}
    >
      <div className="pointer-events-none absolute top-0 right-0 h-32 w-32 -translate-y-1/2 translate-x-1/2 rounded-full bg-[rgba(var(--warna-brand-rgb),0.1)] blur-3xl transition-transform duration-700 group-hover:scale-110" />

      <div className="relative z-10 mb-5 flex h-24 w-24 items-center justify-center rounded-full bg-[rgba(var(--warna-brand-rgb),0.15)]">
        <span className="text-2xl font-bold text-[var(--warna-aksen)]">{data.inisial}</span>
      </div>

      <span className="relative z-10 mb-3 rounded-full bg-[rgba(var(--warna-brand-rgb),0.2)] px-4 py-1 text-xs font-bold tracking-wider text-[var(--warna-aksen)]">
        {data.posisi}
      </span>

      <h3 className="relative z-10 text-lg font-bold text-[var(--warna-teks-utama)]">{data.nama}</h3>
    </div>
  );
}

export default function OrganizationStructure() {
  const sectionRef = useRef<HTMLDivElement>(null);
  gunakanAnimasiFadeUp(sectionRef);

  return (
    <section
      id="structure"
      ref={sectionRef}
      className="relative overflow-hidden bg-[var(--warna-bg-dasar)] section-alt py-24"
    >
      <div className="bg-dots absolute inset-0 opacity-20" />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_50%_50%,rgba(var(--warna-brand-rgb),0.05)_0%,transparent_60%)]" />

      <div className="relative z-10 mx-auto max-w-7xl px-6">
        <div className="fade-up mx-auto mb-14 max-w-2xl text-center">
          <h2 className="mb-4 text-4xl font-bold tracking-tight text-[var(--warna-teks-utama)] lg:text-5xl">
            Structure <span className="text-[var(--warna-brand)]">Organization</span>
          </h2>
          <p className="text-sm text-[var(--warna-teks-sekunder)] md:text-base">
            Tim inti yang memimpin arah strategis dan operasional PT Yhoiki Digital Nusantara.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-4">
          <div className="fade-up kartu-shadow foto-gedung relative hidden h-full min-h-100 overflow-hidden rounded-2xl lg:block">
            <img
              src="/building.jpg"
              alt="Gedung PT Yhoiki Digital Nusantara"
              className="absolute inset-0 h-full w-full object-cover"
            />
          </div>

          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:col-span-3">
            {daftarPengurus.map((data, index) => (
              <KartuPengurus key={data.nama} data={data} index={index} />
            ))}
          </div>
        </div>
      </div>

      <style
        dangerouslySetInnerHTML={{
          __html: `.fade-up {
 opacity: 0;
 transform: translateY(20px);
 transition: opacity 0.6s ease-out, transform 0.6s ease-out;
 }
 .fade-up.visible {
 opacity: 1;
 transform: translateY(0);
 }`,
        }}
      />
    </section>
  );
}
